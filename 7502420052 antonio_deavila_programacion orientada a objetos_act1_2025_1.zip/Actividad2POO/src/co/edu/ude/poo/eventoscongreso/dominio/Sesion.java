package co.edu.ude.poo.eventoscongreso.dominio;

import java.util.List;

public class Sesion {
    private String fecha;
    private String hora;
    private Sala sala;
    private List<Trabajo> trabajos;
    private Congresista chairman;

    public Sesion() {}

    public Sesion(String fecha, String hora, Sala sala, List<Trabajo> trabajos, Congresista chairman) {
        this.fecha = fecha;
        this.hora = hora;
        this.sala = sala;
        this.trabajos = trabajos;
        this.chairman = chairman;
    }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public String getHora() { return hora; }
    public void setHora(String hora) { this.hora = hora; }

    public Sala getSala() { return sala; }
    public void setSala(Sala sala) { this.sala = sala; }

    public List<Trabajo> getTrabajos() { return trabajos; }
    public void setTrabajos(List<Trabajo> trabajos) { this.trabajos = trabajos; }

    public Congresista getChairman() { return chairman; }
    public void setChairman(Congresista chairman) { this.chairman = chairman; }

    @Override
    public String toString() {
        return "Sesión: " + fecha + " " + hora + " | Sala: " + sala + " | Chairman: " + chairman + " | Trabajos: " + trabajos;
    }
}
