package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Congresista;
import java.util.ArrayList;
import java.util.List;

public class CongresistaCrud {
    private static List<Congresista> lista = new ArrayList<>();

    public static void agregar(Congresista c) throws Exception {
        for (Congresista con : lista) {
            if (con.getCorreo().equalsIgnoreCase(c.getCorreo())) {
                throw new Exception("⚠ Ya existe un congresista con este correo.");
            }
        }
        lista.add(c);
    }

    public static Congresista buscarPorCorreo(String correo) throws Exception {
        for (Congresista c : lista) {
            if (c.getCorreo().equalsIgnoreCase(correo)) {
                return c;
            }
        }
        throw new Exception("❌ No se encontró congresista con ese correo.");
    }

    public static void editar(Congresista actualizado) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCorreo().equalsIgnoreCase(actualizado.getCorreo())) {
                lista.set(i, actualizado);
                return;
            }
        }
        throw new Exception("❌ No se encontró congresista a editar.");
    }

    public static void eliminar(String correo) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCorreo().equalsIgnoreCase(correo)) {
                lista.remove(i);
                return;
            }
        }
        throw new Exception("❌ No se encontró congresista a eliminar.");
    }

    public static List<Congresista> listarTodo() {
        return lista;
    }

    public static int contar() {
        return lista.size();
    }
}
