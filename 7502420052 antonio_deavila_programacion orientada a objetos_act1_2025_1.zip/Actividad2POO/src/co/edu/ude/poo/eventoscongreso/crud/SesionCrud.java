package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Sesion;
import java.util.ArrayList;
import java.util.List;

public class SesionCrud {
    private static List<Sesion> lista = new ArrayList<>();

    private static String clave(Sesion s) {
        return s.getFecha() + " " + s.getHora();
    }

    public static void agregar(Sesion s) throws Exception {
        for (Sesion sesion : lista) {
            if (clave(sesion).equalsIgnoreCase(clave(s))) {
                throw new Exception("⚠ Ya existe una sesión con esa fecha y hora.");
            }
        }
        lista.add(s);
    }

    public static Sesion buscar(String fecha, String hora) throws Exception {
        for (Sesion s : lista) {
            if (clave(s).equalsIgnoreCase(fecha + " " + hora)) {
                return s;
            }
        }
        throw new Exception("❌ No se encontró sesión.");
    }

    public static void editar(Sesion actualizada) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (clave(lista.get(i)).equalsIgnoreCase(clave(actualizada))) {
                lista.set(i, actualizada);
                return;
            }
        }
        throw new Exception("❌ No se encontró sesión a editar.");
    }

    public static void eliminar(String fecha, String hora) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (clave(lista.get(i)).equalsIgnoreCase(fecha + " " + hora)) {
                lista.remove(i);
                return;
            }
        }
        throw new Exception("❌ No se encontró sesión a eliminar.");
    }

    public static List<Sesion> listarTodo() {
        return lista;
    }

    public static int contar() {
        return lista.size();
    }
}
