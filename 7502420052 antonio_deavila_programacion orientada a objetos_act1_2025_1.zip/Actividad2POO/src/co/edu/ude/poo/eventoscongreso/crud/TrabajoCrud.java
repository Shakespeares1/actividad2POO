package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Trabajo;
import java.util.ArrayList;
import java.util.List;

public class TrabajoCrud {
    private static List<Trabajo> lista = new ArrayList<>();

    public static void agregar(Trabajo t) throws Exception {
        for (Trabajo tr : lista) {
            if (tr.getTitulo().equalsIgnoreCase(t.getTitulo())) {
                throw new Exception("⚠ Ya existe un trabajo con ese título.");
            }
        }
        lista.add(t);
    }

    public static Trabajo buscarPorTitulo(String titulo) throws Exception {
        for (Trabajo t : lista) {
            if (t.getTitulo().equalsIgnoreCase(titulo)) {
                return t;
            }
        }
        throw new Exception("❌ No se encontró trabajo con ese título.");
    }

    public static void editar(Trabajo actualizado) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getTitulo().equalsIgnoreCase(actualizado.getTitulo())) {
                lista.set(i, actualizado);
                return;
            }
        }
        throw new Exception("❌ No se encontró trabajo a editar.");
    }

    public static void eliminar(String titulo) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getTitulo().equalsIgnoreCase(titulo)) {
                lista.remove(i);
                return;
            }
        }
        throw new Exception("❌ No se encontró trabajo a eliminar.");
    }

    public static List<Trabajo> listarTodo() {
        return lista;
    }

    public static int contar() {
        return lista.size();
    }
}
