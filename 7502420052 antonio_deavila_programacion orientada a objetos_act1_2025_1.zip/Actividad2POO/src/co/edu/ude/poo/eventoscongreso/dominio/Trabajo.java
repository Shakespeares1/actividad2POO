package co.edu.ude.poo.eventoscongreso.dominio;

import java.util.List;

public class Trabajo {
    private String titulo;
    private String resumen;
    private List<Congresista> autores;
    private boolean seleccionado;

    public Trabajo() {}

    public Trabajo(String titulo, String resumen, List<Congresista> autores, boolean seleccionado) {
        this.titulo = titulo;
        this.resumen = resumen;
        this.autores = autores;
        this.seleccionado = seleccionado;
    }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getResumen() { return resumen; }
    public void setResumen(String resumen) { this.resumen = resumen; }

    public List<Congresista> getAutores() { return autores; }
    public void setAutores(List<Congresista> autores) { this.autores = autores; }

    public boolean isSeleccionado() { return seleccionado; }
    public void setSeleccionado(boolean seleccionado) { this.seleccionado = seleccionado; }

    @Override
    public String toString() {
        return "Trabajo: " + titulo + " | " + resumen + " | Autores: " + autores + " | Seleccionado: " + seleccionado;
    }
}
